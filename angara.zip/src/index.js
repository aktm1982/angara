import './assets/scss/style.scss'
import './assets/scss/news.scss'
import './assets/scss/dummy.scss'
import './assets/scss/production.scss'
import './assets/scss/generic.scss'
import './assets/scss/machinery.scss'
import './assets/scss/social_politic.scss'
import './assets/scss/about.scss'

window.onload = () => {

    const counterDisplays = document.querySelectorAll(".counter_display");
    const animationTime = 5000;
    const animationSpeed = 250;

    const animateIncrease = (elt, animationStep = 0) => {
        const targetValue = elt.dataset.targetValue;
        const targetFixed = elt.dataset.targetFixed;
        const increaseValue = targetValue / (animationTime / animationSpeed);

        const getCurrentValue = (animationStep) => animationStep * increaseValue;

        const animate = () => {
            elt.innerText = getCurrentValue(animationStep).toFixed(targetFixed).replace('.', ',');
            animationStep++;
            if (elt.innerText < targetValue) {
                requestAnimationFrame(animate);
            } else {
                elt.innerText = targetValue.replace('.', ',');
            }
        }

        animate();  
    }

    const counterHandler = () => {
        counterDisplays.forEach(elt => {
            if (elt.offsetTop < ( window.scrollY + window.innerHeight * 0.6)) {
                window.removeEventListener('scroll', counterHandler);
                animateIncrease(elt);
            }
        })
    }

    window.addEventListener('scroll', counterHandler); 

    const animatedBlocks = document.querySelectorAll(".animated");

    const animateVisibility = (elt) => {
        if (elt.offsetTop < ( window.scrollY + window.innerHeight * 0.6)) {
            elt.style.opacity = 1;
        }
    }

    window.onscroll = () => animatedBlocks.forEach(animateVisibility);
}